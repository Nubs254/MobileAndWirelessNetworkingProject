package com.example.tictactoe;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class PlayerSetupMultiplayer extends AppCompatActivity implements OnClickListener {

    private EditText edit_textUsername;
    private Button buttonUsername;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.player_setup_multiplayer);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.username), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        edit_textUsername = (EditText) findViewById(R.id.edit_textUsername);
        buttonUsername = (Button) findViewById(R.id.buttonUsername);
    }

    @Override
    public void onClick(View view) {
        if ((Button) view == buttonUsername) {
            if (!edit_textUsername.getText().toString().isEmpty()) {
                try (FileWriter writer = new FileWriter(new File(this.getFilesDir(), "username.txt"))) {
                    writer.write(edit_textUsername.getText().toString() + "\n");
                    writer.flush();
                } catch (IOException e) {
                    Log.e("File Write", Log.getStackTraceString(e));
                }
            }
            Intent intent = new Intent(this, NetworkSetup.class);
            intent.putExtra("USERNAME", !edit_textUsername.getText().toString().isEmpty() ? edit_textUsername.getText().toString() : "Anonymous");
            startActivity(intent);
        }
    }
}