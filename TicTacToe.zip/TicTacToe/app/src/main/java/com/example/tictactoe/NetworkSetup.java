package com.example.tictactoe;

import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.LinkAddress;
import android.net.LinkProperties;
import android.net.NetworkCapabilities;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.Inet4Address;
import java.net.Inet6Address;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Random;
import java.util.concurrent.Semaphore;

public class NetworkSetup extends AppCompatActivity implements OnClickListener {

    public static volatile String strInetAddr, strPublicInetAddr;
    public static volatile boolean bInet6Addr;
    public static volatile ServerSocket server_socketVar;
    public static volatile Thread threadConnection;
    public static volatile Semaphore semMyTurn, semSwitchTurn;
    private String strUsername;

    private void reset_class_variables() {
        strInetAddr = null;
        strPublicInetAddr = null;
        bInet6Addr = false;
        if (server_socketVar != null) {
            try {
                server_socketVar.close();
            } catch (IOException e) {
                Log.e("Socket Close", Log.getStackTraceString(e));
            }
        }
        server_socketVar = null;
        if (threadConnection != null)
            threadConnection.interrupt();
        threadConnection = null;
        semMyTurn = null;
        semSwitchTurn = null;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.multiplayer_layout);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.multiplayer), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        server_socketVar = null;
        threadConnection = null;
        reset_class_variables();
        strUsername = getIntent().getStringExtra("USERNAME") != null ? getIntent().getStringExtra("USERNAME") : "Anonymous";
    }

    @Override
    public void onClick(View view) {
        if (view == (View) findViewById(R.id.buttonHost)) {
            button_host_action();
            if (strInetAddr != null) {
                setContentView(R.layout.host_connection_layout);
                if (!bInet6Addr)
                    ((TextView) findViewById(R.id.textIP)).setText(Html.fromHtml("<b>IP:</B> " + strInetAddr, Html.FROM_HTML_MODE_LEGACY));
                else
                    ((TextView) findViewById(R.id.textIP)).setText(Html.fromHtml("local IPv4 address unavailable; show public IP first to see local IPv6 address upon redisplay of local IP", Html.FROM_HTML_MODE_LEGACY));
                if (server_socketVar != null)
                    ((TextView) findViewById(R.id.textPort)).setText(Html.fromHtml("<b>Port:</B> " + server_socketVar.getLocalPort(), Html.FROM_HTML_MODE_LEGACY));
                else
                    ((TextView) findViewById(R.id.textPort)).setText(Html.fromHtml("<b>Port:</B> " + "port number unavailable due to socket open error", Html.FROM_HTML_MODE_LEGACY));
            } else
                setContentView(R.layout.no_network_layout);
        } else if (view == (View) findViewById(R.id.buttonMenuConnect)) {
            setContentView(R.layout.direct_connect_layout);
        } else if (view == (View) findViewById(R.id.buttonPublicIP)) {
            if (((Button) view).getText().toString().equals(getString(R.string.button_public_IP_text))) {
                ((TextView) findViewById(R.id.textIP)).setText(Html.fromHtml("<b>Public IP:</B> " + strPublicInetAddr, Html.FROM_HTML_MODE_LEGACY));
                int iWidth = ((Button) view).getWidth();
                ((Button) view).setText(R.string.hide_public_IP_text);
                ((Button) view).setWidth(iWidth);
            } else {
                ((TextView) findViewById(R.id.textIP)).setText(Html.fromHtml("<b>IP:</B> " + strInetAddr, Html.FROM_HTML_MODE_LEGACY));
                ((Button) view).setText(R.string.button_public_IP_text);
            }
        } else if (view == (View) findViewById(R.id.buttonConnect)) {
            button_connect_action();
        } else if (view == (View) findViewById(R.id.buttonHostConnectionMenuReturn) ||
                view == (View) findViewById(R.id.buttonNoNetworkMenuReturn) ||
                view == (View) findViewById(R.id.buttonDirectConnectMenuReturn)) {
            setContentView(R.layout.multiplayer_layout);
            reset_class_variables();
        }
    }

    private int check_network_connection_and_ip_query() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        NetworkCapabilities nc = cm.getNetworkCapabilities(cm.getActiveNetwork());
        if (nc == null || (!nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) && !nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) && !nc.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)))
            return 1;
        LinkProperties lpActiveNetwork = cm.getLinkProperties(cm.getActiveNetwork());
        boolean bMultipleInet6Addr = false;
        if (lpActiveNetwork != null) {
            for (LinkAddress la : lpActiveNetwork.getLinkAddresses()) {
                if (la.getAddress() instanceof Inet4Address && !la.getAddress().isLinkLocalAddress() && !la.getAddress().isLoopbackAddress() && la.getAddress().getHostAddress() != null) {
                    if (strInetAddr == null || bInet6Addr) {
                        strInetAddr = la.getAddress().getHostAddress();
                        bInet6Addr = false;
                    } else {
                        strInetAddr = null;
                        break;
                    }
                } else if (la.getAddress() instanceof Inet6Address && !la.getAddress().isLinkLocalAddress() && !la.getAddress().isLoopbackAddress() && la.getAddress().getHostAddress() != null) {
                    Log.i("Local IPv6", la.getAddress().getHostAddress());
                    Log.i("Local IPv6", la.getAddress().getHostAddress().split("%")[0]);
                    if (strInetAddr == null) {
                        strInetAddr = la.getAddress().getHostAddress().split("%")[0];
                        bInet6Addr = true;
                    } else if (bInet6Addr)
                        bMultipleInet6Addr = true;
                }
            }
            if (bInet6Addr && bMultipleInet6Addr)
                strInetAddr = null;
        }
        if (strInetAddr == null)
            return 1;
        //Log.i("Local IP", strInetAddr);
        new Thread(() -> {
            for (String strURL : new String[] {"https://checkip.amazonaws.com", "https://api.ipify.org", "https://myexternalip.com/raw"}) {
                BufferedReader brInput = null;
                try {
                    brInput = new BufferedReader(new InputStreamReader(new URL(strURL).openStream()));
                    strPublicInetAddr = brInput.readLine();
                    //Log.i("Public IP", strPublicInetAddr);
                    break;
                } catch (IOException e) {
                    boolean bErrorPrintOverrideNeeded = false;
                    Throwable t = (Throwable) e;
                    while (t != null) {
                        if (t instanceof UnknownHostException) {
                            bErrorPrintOverrideNeeded = true;
                            break;
                        }
                        t = t.getCause();
                    }
                    if (!bErrorPrintOverrideNeeded)
                        Log.e("IP Query", Log.getStackTraceString(e));
                    else {
                        StringWriter swErrorMessage = new StringWriter();
                        e.printStackTrace(new PrintWriter(swErrorMessage));
                        Log.e("IP Query", swErrorMessage.toString());
                    }
                } finally {
                    if (brInput != null) {
                        try {
                            brInput.close();
                        } catch (IOException e) {
                            Log.e("IP Query", Log.getStackTraceString(e));
                        }
                    }
                }
            }
            if (strPublicInetAddr == null)
                strPublicInetAddr = "unavailable";
        }).start();
        return 0;
    }

    private void button_host_action() {
        if (check_network_connection_and_ip_query() != 0)
            return;
        try {
            server_socketVar = new ServerSocket(34807);
        } catch (IOException e) {
            Log.e("Socket Open", Log.getStackTraceString(e));
            return;
        }
        threadConnection = new Thread(() -> {
            Socket socketConnection = null;
            try {
                socketConnection = server_socketVar.accept();
            } catch (IOException e) {
                Log.e("Socket Accept", Log.getStackTraceString(e));
                return;
            }
            try {
                server_socketVar.close();
            } catch (IOException e) {
                Log.e("Socket Close", Log.getStackTraceString(e));
            }
            server_socketVar = null;
            if (socketConnection != null) {
                BufferedReader brInput = null;
                DataOutputStream dosOutput = null;
                String strInput = null;
                boolean bMeFirst = new Random().nextInt(2) == 0;
                try {
                    brInput = new BufferedReader(new InputStreamReader(socketConnection.getInputStream()));
                } catch (IOException e) {
                    Log.e("Socket Read", Log.getStackTraceString(e));
                    //toast - connection setup failed. new port number has been assigned for future requests.
                }
                try {
                    if (brInput != null) {
                        dosOutput = new DataOutputStream(socketConnection.getOutputStream());
                        dosOutput.writeBytes(bMeFirst ? strUsername + " first\n" : strUsername + " second\n");
                    }
                } catch (IOException e) {
                    Log.e("Socket Write", Log.getStackTraceString(e));
                    if (dosOutput != null) {
                        try {
                            dosOutput.close();
                        } catch (IOException eVar) {
                            Log.e("Socket Close", Log.getStackTraceString(eVar));
                        }
                        dosOutput = null;
                    }
                    //toast - connection setup failed. new port number has been assigned for future requests.
                }
                if (dosOutput != null) {
                    boolean bNoError = true;
                    try {
                        socketConnection.setSoTimeout(1000);
                    } catch (SocketException e) {
                        Log.e("Socket Config", Log.getStackTraceString(e));
                        bNoError = false;
                        //toast - connection setup failed. please try again.
                    }
                    try {
                        strInput = brInput.readLine();
                        if (strInput == null) {
                            Log.e("Socket Read", "connection closed by other application");
                            bNoError = false;
                            //toast - connection setup failed. please try again.
                        } else
                            ;//Log.i("Connection Handshake - Join Read", "\"" + strInput + "\"");
                    } catch (IOException e) {
                        Log.e("Socket Read", Log.getStackTraceString(e));
                        bNoError = false;
                        //toast - connection setup failed. please try again.
                    }
                    if (strInput != null && (!strInput.contains("OK. " + (bMeFirst ? strUsername + " first. " : strUsername + " second. ")) || strInput.split("\\.", 4).length != 4 || strInput.split("\\.", 4)[2].split(" ", 2).length != 2 || strInput.split("\\.", 4)[2].split(" ", 2)[1].split(" ", 2).length != 2))
                        bNoError = false;
                    if (bNoError)
                        alternating_click_network_loop(brInput, dosOutput, true, bMeFirst, strInput.split("\\.", 4)[2].split(" ", 2)[1].split(" ", 2)[0]);
                }
                try {
                    if (brInput != null)
                        brInput.close();
                    if (dosOutput != null)
                        dosOutput.close();
                    socketConnection.close();
                } catch (IOException e) {
                    Log.e("Socket Close", Log.getStackTraceString(e));
                }
            }
        });
        threadConnection.start();
    }

    private void button_connect_action() {
        threadConnection = new Thread(() -> {
            Socket socketConnection = null;
            try {
                socketConnection = new Socket(((EditText) findViewById(R.id.edit_textIP)).getText().toString(), Integer.parseInt(((EditText) findViewById(R.id.edit_textPort)).getText().toString()));
            } catch (IOException | NumberFormatException e) {
                Log.e("Socket Connect", Log.getStackTraceString(e));
            }
            if (socketConnection != null) {
                BufferedReader brInput = null;
                DataOutputStream dosOutput = null;
                String strInput = null;
                boolean bMeFirst = false;
                try {
                    brInput = new BufferedReader(new InputStreamReader(socketConnection.getInputStream()));
                    strInput = brInput.readLine();
                    if (strInput != null) {
                        //Log.i("Connection Handshake - Host Read", "\"" + strInput + "\"");
                        bMeFirst = strInput.contains("second");
                    } else
                        ;//toast - connection setup failed. please try again.
                } catch (IOException e) {
                    Log.e("Socket Read", Log.getStackTraceString(e));
                    if (brInput != null) {
                        try {
                            brInput.close();
                        } catch (IOException eVar) {
                            Log.e("Socket Close", Log.getStackTraceString(eVar));
                        }
                        brInput = null;
                    }
                    //toast - connection setup failed. please try again.
                }
                try {
                    if (brInput != null && strInput != null) {
                        dosOutput = new DataOutputStream(socketConnection.getOutputStream());
                        dosOutput.writeBytes("OK. " + strInput + ". " + strUsername + (bMeFirst ? " first.\n" : " second.\n"));
                    }
                } catch (IOException e) {
                    Log.e("Socket Write", Log.getStackTraceString(e));
                    //toast - connection setup failed. please try again.
                }
                if (dosOutput != null) {
                    boolean bNoError = true;
                    try {
                        socketConnection.setSoTimeout(1000);
                    } catch (SocketException e) {
                        Log.e("Socket Config", Log.getStackTraceString(e));
                        bNoError = false;
                        //toast - connection setup failed. please try again.
                    }
                    if (strInput.split(" ", 2).length != 2)
                        bNoError = false;
                    if (bNoError)
                        alternating_click_network_loop(brInput, dosOutput, false, bMeFirst, strInput.split(" ", 2)[0]);
                }
                try {
                    if (brInput != null)
                        brInput.close();
                    if (dosOutput != null)
                        dosOutput.close();
                    socketConnection.close();
                } catch (IOException e) {
                    Log.e("Socket Close", Log.getStackTraceString(e));
                }
            }
        });
        threadConnection.start();
    }

    private void alternating_click_network_loop(BufferedReader brInput, DataOutputStream dosOutput, boolean bConnectionHost, boolean bMeFirst, String strOpponentUsername) {
        String strInput = null;
        boolean bNoError = true;
        semMyTurn = bMeFirst ? new Semaphore(1) : new Semaphore(0);
        semSwitchTurn = new Semaphore(0);
        if (strUsername.equals(strOpponentUsername)) {
            strUsername += bConnectionHost ? " (Host Player)" : " (Join Player)";
            strOpponentUsername += bConnectionHost ? " (Join Player)" : " (Host Player)";
        }
        Intent intent = new Intent(this, GameDisplay.class);
        intent.putExtra("PLAYER_NAMES", bMeFirst ? new String[] {strUsername, strOpponentUsername} : new String[] {strOpponentUsername, strUsername});
        intent.putExtra("GAME_TYPE", "Multiplayer");
        startActivity(intent);
        if (bMeFirst) {
            try {
                semSwitchTurn.acquire();
            } catch (InterruptedException e) {
                Log.e("Semaphore Acquire", Log.getStackTraceString(e));
                bNoError = false;
            }
            try {
                if (bNoError)
                    dosOutput.writeBytes("Moved /" + GameDisplay.ticTacToeBoard.col + "," + GameDisplay.ticTacToeBoard.row + "/. Your Turn.\n");
            } catch (IOException e) {
                Log.e("Socket Write", Log.getStackTraceString(e));
                bNoError = false;
                //runOnUiThread(() -> setContentView(R.layout.multiplayer_layout));
                threadConnection = null;
                reset_class_variables();
                //toast - connection closed by other application
            }
        }
        while (bNoError) {
            try {
                while (true) {
                    try {
                        strInput = brInput.readLine();
                        break;
                    } catch (SocketTimeoutException ignore) {
                        if (Thread.currentThread().isInterrupted()) {
                            bNoError = false;
                            break;
                        }
                    }
                }
            } catch (IOException e) {
                Log.e("Socket Read", Log.getStackTraceString(e));
                //runOnUiThread(() -> setContentView(R.layout.multiplayer_layout));
                threadConnection = null;
                reset_class_variables();
                //toast - connection closed due to network error
                break;
            }
            if (!bNoError)
                break;
            if (strInput == null) {
                Log.e("Socket Read", "connection closed by other application");
                //runOnUiThread(() -> setContentView(R.layout.multiplayer_layout));
                threadConnection = null;
                reset_class_variables();
                //toast - connection closed by other application
                break;
            }
            String[] strTokenM = strInput.split("/");
            if (strTokenM.length == 3 && strTokenM[0].equals("Moved ") && strTokenM[2].equals(". Your Turn.") && strTokenM[1].split(",").length == 2) {
                int col, row;
                try {
                    col = Integer.parseInt(strTokenM[1].split(",")[0]);
                    row = Integer.parseInt(strTokenM[1].split(",")[1]);
                } catch (NumberFormatException e) {
                    Log.e("Socket Read", Log.getStackTraceString(e));
                    continue;
                }
                GameDisplay.gdInstance.runOnUiThread(() ->  {
                    GameDisplay.ticTacToeBoard.game.updateGameBoard(row, col);
                    GameDisplay.ticTacToeBoard.invalidate();
                    if (GameDisplay.ticTacToeBoard.game.winnerCheck()) {
                        GameDisplay.ticTacToeBoard.winningLine = true;
                        GameDisplay.ticTacToeBoard.invalidate();
                        threadConnection.interrupt();
                    } else {
                        if (GameDisplay.ticTacToeBoard.game.getPlayer() % 2 == 0)
                            GameDisplay.ticTacToeBoard.game.setPlayer(GameDisplay.ticTacToeBoard.game.getPlayer() - 1);
                        else
                            GameDisplay.ticTacToeBoard.game.setPlayer(GameDisplay.ticTacToeBoard.game.getPlayer() + 1);
                        semMyTurn.release();
                    }
                });
                try {
                    semSwitchTurn.acquire();
                } catch (InterruptedException e) {
                    Log.e("Semaphore Acquire", Log.getStackTraceString(e));
                    break;
                }
                try {
                    dosOutput.writeBytes("Moved /" + GameDisplay.ticTacToeBoard.col + "," + GameDisplay.ticTacToeBoard.row + "/. Your Turn.\n");
                } catch (IOException e) {
                    Log.e("Socket Write", Log.getStackTraceString(e));
                    //runOnUiThread(() -> setContentView(R.layout.multiplayer_layout));
                    threadConnection = null;
                    reset_class_variables();
                    //toast - connection closed by other application
                    break;
                }
            }
        }
    }
}