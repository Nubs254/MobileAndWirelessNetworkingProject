package com.example.tictactoe;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity {

    private boolean bFirstEntry;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        bFirstEntry = !getIntent().getBooleanExtra("REENTRY", false);
    }

    public void playButtonClick(View view) {
        if (view == (View) findViewById(R.id.buttonLocalPlay)) {
            Intent intent = new Intent(this, PlayerSetup.class);
            startActivity(intent);
        } else if (view == (View) findViewById(R.id.buttonMultiplayer)) {
            if (!new File(this.getFilesDir(), "username.txt").exists() && bFirstEntry) {
                bFirstEntry = false;
                Log.i("Test", "File does not exist!");
                Intent intent = new Intent(this, PlayerSetupMultiplayer.class);
                startActivity(intent);
            } else {
                String strUsername = "Anonymous";
                if (new File(this.getFilesDir(), "username.txt").exists()) {
                    Log.i("Test", "File exists!");
                    try (Scanner scan = new Scanner(new File(this.getFilesDir(), "username.txt"))) {
                        if (scan.hasNextLine())
                            strUsername = scan.nextLine();
                    } catch (FileNotFoundException e) {
                        Log.e("File Read", Log.getStackTraceString(e));
                    }
                }
                Intent intent = new Intent(this, NetworkSetup.class);
                intent.putExtra("USERNAME", strUsername);
                startActivity(intent);
            }
        }
    }
}